<?php
    // $db_name = "id19028635_dbpercobaan";
    // $username = "id19028635_percobaan";
    // $password = "FHveRI6j(kkcL~PK";
    // $servename = "localhost";
    // $conn = mysqli_connect($servename ,$username ,$password ,$db_name );

    $db_name = "sql6501652";
    $username = "sql6501652";
    $password = "nCmQkgX2LM";
    $servename = "sql6.freesqldatabase.com";
    $conn = mysqli_connect($servename ,$username ,$password ,$db_name );
?>